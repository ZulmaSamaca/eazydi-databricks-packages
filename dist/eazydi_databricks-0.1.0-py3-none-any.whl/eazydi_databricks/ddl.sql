CREATE TABLE IF NOT EXISTS workspace.default.lnd_tiktok_raw1 (
    ad_id STRING,
    adgroup_id STRING,
    campaign_id STRING,
    campaign_name STRING,
    impressions STRING,
    clicks STRING,
    spend STRING,
    ctr STRING,
    cpc STRING,
    conversion STRING,
    frequency STRING,
    cash_spend STRING,
    video_play_actions STRING,
    likes STRING,
    shares STRING,
    follows STRING,
    profile_visits STRING,
    country_code STRING
)
USING DELTA;

CREATE TABLE IF NOT EXISTS workspace.default.fct_tiktok_ad_insights (
    ad_id STRING,
    adgroup_id STRING,
    campaign_id STRING,
    campaign_name STRING,
    impressions INT,
    clicks INT,
    spend FLOAT,
    ctr FLOAT,
    cpc FLOAT,
    conversion INT,
    frequency FLOAT,
    cash_spend FLOAT,
    video_play_actions INT,
    likes INT,
    shares INT,
    follows INT,
    profile_visits INT,
    country_code STRING
)
USING DELTA;

-- INSTAGRAM RAW TABLE
CREATE TABLE IF NOT EXISTS workspace.default.lnd_instagram_raw (
    -- Identificadores
    ad_id STRING,
    ad_name STRING,
    campaign_id STRING,
    campaign_name STRING,

    -- Métricas básicas
    clicks STRING,
    impressions STRING,
    reach STRING,
    frequency STRING,
    spend STRING,
    unique_clicks STRING,

    -- Engagement
    full_view_reach STRING,

    -- Costos
    cpc STRING,
    cpm STRING,
    cpp STRING,

    -- Configuración
    objective STRING,
    publisher_platform STRING,

    -- Timestamps
    created_time STRING,
    updated_time STRING
)
USING DELTA;

-- INSTAGRAM FACT TABLE

CREATE TABLE IF NOT EXISTS workspace.default.fct_instagram_ad (
    ad_id STRING,
    adgroup_id STRING,
    campaign_id STRING,
    campaign_name STRING,
    impressions STRING,
    clicks STRING,
    spend STRING,
    ctr STRING,
    cpc STRING,
    conversion STRING,
    frequency STRING,
    cash_spend STRING,
    video_play_actions STRING,
    likes STRING,
    shares STRING,
    follows STRING,
    profile_visits STRING,
    country_code STRING
)
USING DELTA;

CREATE TABLE IF NOT EXISTS workspace.default.fct_instagram_ad_insights (
    ad_id STRING,
    ad_name STRING,
    campaign_id STRING,
    campaign_name STRING,

    clicks INT,
    impressions INT,
    reach INT,
    frequency FLOAT,
    spend FLOAT,
    unique_clicks INT,

    full_view_reach INT,

    cpc FLOAT,
    cpm FLOAT,
    cpp FLOAT,

    objective STRING,
    publisher_platform STRING,

    created_time TIMESTAMP,
    updated_time TIMESTAMP
)
USING DELTA;

-- FACEBOOK RAW TABLE

CREATE TABLE IF NOT EXISTS workspace.default.lnd_facebook_raw (
    ad_id STRING,
    ad_name STRING,
    adset_id STRING,
    campaign_id STRING,
    campaign_name STRING,

    impressions STRING,
    clicks STRING,
    reach STRING,
    frequency STRING,
    spend STRING,
    unique_clicks STRING,

    ctr STRING,
    cpc STRING,
    cpm STRING,

    created_time STRING,
    updated_time STRING
)
USING DELTA;

-- FACEBOOK FACT TABLE

CREATE TABLE IF NOT EXISTS workspace.default.fct_facebook_ad_insights (
    ad_id STRING,
    ad_name STRING,
    adset_id STRING,
    campaign_id STRING,
    campaign_name STRING,

    impressions INT,
    clicks INT,
    reach INT,
    frequency FLOAT,
    spend FLOAT,
    unique_clicks INT,

    ctr FLOAT,
    cpc FLOAT,
    cpm FLOAT,

    created_time TIMESTAMP,
    updated_time TIMESTAMP
)
USING DELTA;

CREATE TABLE IF NOT EXISTS workspace.default.lnd_tiktok_raw (
    ad_id STRING,
    adgroup_id STRING,
    campaign_id STRING,
    campaign_name STRING,
    impressions STRING,
    clicks STRING,
    spend STRING,
    ctr STRING,
    cpc STRING,
    conversion STRING,
    frequency STRING,
    cash_spend STRING,
    video_play_actions STRING,
    likes STRING,
    shares STRING,
    follows STRING,
    profile_visits STRING,
    country_code STRING
)
USING DELTA;

CREATE TABLE IF NOT EXISTS workspace.default.fct_tiktok_ad_insights (
    ad_id STRING,
    adgroup_id STRING,
    campaign_id STRING,
    campaign_name STRING,
    impressions INT,
    clicks INT,
    spend FLOAT,
    ctr FLOAT,
    cpc FLOAT,
    conversion INT,
    frequency FLOAT,
    cash_spend FLOAT,
    video_play_actions INT,
    likes INT,
    shares INT,
    follows INT,
    profile_visits INT,
    country_code STRING
)
USING DELTA;

CREATE TABLE IF NOT EXISTS workspace.default.lnd_pinterest_raw (
    id STRING,
    ad_account_id STRING,
    name STRING,
    owner STRING,
    country STRING,
    currency STRING,
    permissions STRING,

    bid_options_automatic_bid STRING,
    daily_spend_cap STRING,
    lifetime_spend_cap STRING,

    is_automated_campaign STRING,
    is_campaign_budget_optimization STRING,
    is_flexible_daily_budgets STRING,
    is_performance_plus STRING,

    objective_type STRING,
    order_line_id STRING,
    type STRING,

    status STRING,
    summary_status STRING,

    tracking_urls_click STRING,
    tracking_urls_impression STRING,

    created_time STRING,
    updated_time STRING,
    start_time STRING,
    end_time STRING
)
USING DELTA;

CREATE TABLE IF NOT EXISTS workspace.default.fct_pinterest_ad_insights (
    id STRING,
    ad_account_id STRING,
    name STRING,
    owner STRING,
    country STRING,
    currency STRING,
    permissions STRING,

    bid_options_automatic_bid BOOLEAN,
    daily_spend_cap FLOAT,
    lifetime_spend_cap FLOAT,

    is_automated_campaign BOOLEAN,
    is_campaign_budget_optimization BOOLEAN,
    is_flexible_daily_budgets BOOLEAN,
    is_performance_plus BOOLEAN,

    objective_type STRING,
    order_line_id STRING,
    type STRING,

    status STRING,
    summary_status STRING,

    tracking_urls_click STRING,
    tracking_urls_impression STRING,

    created_time TIMESTAMP,
    updated_time TIMESTAMP,
    start_time TIMESTAMP,
    end_time TIMESTAMP
)
USING DELTA;

-- LANDING TABLE RAW SNAPCHAT ADS
CREATE TABLE IF NOT EXISTS workspace.default.lnd_snapchat_raw (
    ad_squad_id STRING,
    created_at STRING,
    creative_id STRING,
    delivery_status STRING,
    id STRING,
    name STRING,
    render_type STRING,
    review_status STRING,
    status STRING,
    type STRING,
    updated_at STRING
)
USING DELTA;

-- FACT TABLE  SNAPCHAT ADS
CREATE TABLE IF NOT EXISTS workspace.default.fct_snapchat_ad_insights (
    ad_squad_id STRING,
    created_at TIMESTAMP,
    creative_id STRING,
    delivery_status STRING,
    ad_id STRING,
    ad_name STRING,
    render_type STRING,
    review_status STRING,
    status STRING,
    type STRING,
    updated_at TIMESTAMP
)
USING DELTA;

-- LANDING TABLE (RAW LINKEDIN ADS)
CREATE TABLE IF NOT EXISTS workspace.default.lnd_linkedin_raw (
    account STRING,
    campaign STRING,
    content_reference STRING,
    createdAt STRING,
    createdBy STRING,
    id STRING,
    intendedStatus STRING,
    isServing STRING,
    isTest STRING,
    lastModifiedAt STRING,
    lastModifiedBy STRING,
    name STRING,
    review_status STRING,
    servingHoldReasons STRING
)
USING DELTA;

-- FACT TABLE LINKEDIN ADS
CREATE TABLE IF NOT EXISTS workspace.default.fct_linkedin_ad_insights (
    account STRING,
    campaign STRING,
    content_reference STRING,
    created_at TIMESTAMP,
    created_by STRING,
    ad_id STRING,
    intended_status STRING,
    is_serving BOOLEAN,
    is_test BOOLEAN,
    last_modified_at TIMESTAMP,
    last_modified_by STRING,
    ad_name STRING,
    review_status STRING,
    serving_hold_reasons STRING
)
USING DELTA;