import argparse
import logging
import os

from eazydi_databricks.api import (
    build_session,
    signin,
    get_archived_jobs,
    find_batchid_by_mapping_plan_name,
    restart_job,
)
from eazydi_databricks.config import load_json, resolve_config_paths
from eazydi_databricks.ddl import execute_ddl, apply_grants
from eazydi_databricks.spark_transform import run_spark_transform
from pyspark.sql import SparkSession


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--secrets", required=True)
    parser.add_argument("--execute", required=True)
    parser.add_argument("--config-dir", required=True)

    return parser.parse_args()


def main():
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()


    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    logger = logging.getLogger("eazydi_runner")

    secrets = load_json(args.secrets)
    config_files = resolve_config_paths(args.config_dir, args.execute)

    catalog = secrets.get("databricks", {}).get("catalog", "workspace")
    schema = secrets.get("databricks", {}).get("schema", "default")
    principal = secrets.get("databricks", {}).get("grant_principal", "")

    created_tables = execute_ddl(spark, catalog, schema)
    apply_grants(spark, catalog, schema, principal, created_tables)

    session = build_session()
    token = signin(
        session,
        secrets["auth"]["url"],
        secrets["auth"]["username"],
        secrets["auth"]["password"],
    )
    tenant_id = secrets["tenant"]["id"]

    for idx, config_path in enumerate(config_files, start=1):
        logger.info("Executing config %s: %s", idx, os.path.basename(config_path))

        config = load_json(config_path)

        archive_payload = get_archived_jobs(
            session,
            config["endpoints"]["monitor_archive"],
            token,
            tenant_id,
        )

        mapping_plan_name = config["job"]["mapping_plan_name"]
        match_mode = config["job"].get("match_mode", "exact")

        batchid = find_batchid_by_mapping_plan_name(
            archive_payload,
            mapping_plan_name,
            match_mode,
        )

        logger.info("BatchID: %s", batchid)

        restart_job(
            session,
            config["endpoints"]["monitor_restart"],
            token,
            tenant_id,
            batchid,
        )

        logger.info("Restart OK")
        run_spark_transform(spark, config, catalog, schema)


if __name__ == "__main__":
    main()