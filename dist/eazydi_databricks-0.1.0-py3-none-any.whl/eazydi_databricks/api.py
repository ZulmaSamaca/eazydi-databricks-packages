from datetime import datetime
from typing import Any, Dict
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


def build_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=5,
        backoff_factor=0.6,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods={"GET", "POST"},
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


def req(session: requests.Session, method: str, url: str, **kwargs) -> requests.Response:
    return session.request(method, url, timeout=30, **kwargs)


def signin(session: requests.Session, auth_url: str, username: str, password: str) -> str:
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Origin": "https://sandbox.eazydi.com",
        "Referer": "https://sandbox.eazydi.com/sign-in",
    }
    resp = session.post(
        auth_url,
        json={"username": username.strip(), "password": password.strip()},
        headers=headers,
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    token = data.get("token") or data.get("accessToken") or data.get("data", {}).get("token")
    if not token:
        raise RuntimeError(f"Missing token in auth response: {resp.text}")
    return token


def get_archived_jobs(
    session: requests.Session,
    url: str,
    token: str,
    tenant_id: str,
) -> Dict[str, Any]:
    headers = {
        "Authorization": token,
        "X-EazydiTenant-Id": tenant_id,
        "Accept": "application/json",
    }
    response = req(session, "GET", url, headers=headers)
    if response.status_code != 200:
        raise RuntimeError(f"Archive fetch failed ({response.status_code}): {response.text}")
    return response.json()


def _parse_dt(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None


def find_batchid_by_mapping_plan_name(
    payload: dict,
    mapping_plan_name: str,
    match_mode: str = "exact",
) -> str:
    items = payload.get("success", {}).get("respObject", [])
    if not isinstance(items, list):
        raise ValueError("Unexpected payload: success.respObject is not a list.")

    target = (mapping_plan_name or "").strip().lower()
    mode = (match_mode or "exact").strip().lower()

    matches = []
    for item in items:
        name = str(item.get("mappingPlanName", "")).strip().lower()
        if not name:
            continue
        if mode == "contains":
            if target in name:
                matches.append(item)
        else:
            if name == target:
                matches.append(item)

    if not matches:
        available = sorted({str(i.get("mappingPlanName", "")).strip() for i in items if i.get("mappingPlanName")})
        raise ValueError(
            f"No job matched mappingPlanName='{mapping_plan_name}' (mode={match_mode}). "
            f"Available examples: {available[:20]}"
        )

    def recency_key(item: dict):
        for key in ("queuedTsamp", "startedTsamp", "completedTsamp", "updatedTsamp"):
            dt = _parse_dt(item.get(key))
            if dt is not None:
                return dt
        return datetime.min

    best = max(matches, key=recency_key)

    batchid = best.get("batchid")
    if not batchid:
        raise KeyError(f"Matched job has no 'batchid'. Keys: {list(best.keys())}")

    picked_name = best.get("mappingPlanName")
    picked_ts = best.get("queuedTsamp") or best.get("startedTsamp") or best.get("completedTsamp")
    print(f"Picked latest match: mappingPlanName={picked_name}, ts={picked_ts}, batchid={batchid}")

    return str(batchid)


def restart_job(
    session: requests.Session,
    url: str,
    token: str,
    tenant_id: str,
    batchid: str,
) -> Dict[str, Any]:
    headers = {
        "Authorization": token,
        "X-EazydiTenant-Id": tenant_id,
        "Content-Type": "application/json",
    }
    payload = {"batchid": batchid}
    response = req(session, "POST", url, headers=headers, json=payload)
    if response.status_code != 200:
        raise RuntimeError(f"Restart failed ({response.status_code}): {response.text}")
    return response.json() if response.text.strip() else {"status": "ok"}