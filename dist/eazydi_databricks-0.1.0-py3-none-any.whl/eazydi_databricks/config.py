import json
import os
import re
from typing import Any, Dict, List


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def normalize_config_name(name: str) -> str:
    name = name.strip()
    if not name:
        return ""

    name = name.split("#", 1)[0].strip()
    if not name:
        return ""

    name = name.strip("\"'").strip()
    name = re.sub(r"\s+", " ", name)

    if not name.lower().endswith(".json"):
        name = f"{name}.json"

    return name


def read_execute_list(execute_path: str) -> List[str]:
    if not os.path.exists(execute_path):
        raise FileNotFoundError(f"No existe el archivo execute: {execute_path}")

    with open(execute_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    names = []
    for line in lines:
        line = line.split("#", 1)[0].strip()
        if not line:
            continue

        parts = re.split(r"[;,]", line)
        for part in parts:
            cfg = normalize_config_name(part)
            if cfg:
                names.append(cfg)

    seen = set()
    unique = []
    for item in names:
        if item not in seen:
            seen.add(item)
            unique.append(item)

    return unique


def resolve_config_paths(config_dir: str, execute_path: str) -> List[str]:
    requested = read_execute_list(execute_path)
    paths = []

    for name in requested:
        full_path = os.path.join(config_dir, name)
        if not os.path.exists(full_path):
            raise FileNotFoundError(f"No existe config: {full_path}")
        paths.append(full_path)

    return paths