import time

import pyspark.sql.functions as F
from pyspark.sql.functions import col, when


def wait_for_data(spark, table: str, timeout: int = 180, interval: int = 10) -> None:
    start = time.time()

    while True:
        count = spark.table(table).count()

        if count > 0:
            print(f"Data detected in {table}: {count} rows")
            return

        if time.time() - start > timeout:
            raise TimeoutError(f"No data in {table} after {timeout} seconds")

        print(f"Waiting for data in {table}...")
        time.sleep(interval)


def cast_tiktok(df):
    return (
        df
        .withColumn("impressions", col("impressions").cast("int"))
        .withColumn("clicks", col("clicks").cast("int"))
        .withColumn("spend", col("spend").cast("float"))
        .withColumn("conversion", col("conversion").cast("int"))
        .withColumn("frequency", col("frequency").cast("float"))
        .withColumn("cash_spend", col("cash_spend").cast("float"))
        .withColumn("video_play_actions", col("video_play_actions").cast("int"))
        .withColumn("likes", col("likes").cast("int"))
        .withColumn("shares", col("shares").cast("int"))
        .withColumn("follows", col("follows").cast("int"))
        .withColumn("profile_visits", col("profile_visits").cast("int"))
        .withColumn("ctr", when(col("impressions") > 0, col("clicks") / col("impressions")).otherwise(None).cast("float"))
        .withColumn("cpc", when(col("clicks") > 0, col("spend") / col("clicks")).otherwise(None).cast("float"))
    )
def cast_pinterest(df):
    return (
        df
        .withColumn("bid_options_automatic_bid", col("bid_options_automatic_bid").cast("boolean"))
        .withColumn("daily_spend_cap", col("daily_spend_cap").cast("float"))
        .withColumn("lifetime_spend_cap", col("lifetime_spend_cap").cast("float"))
        .withColumn("is_automated_campaign", col("is_automated_campaign").cast("boolean"))
        .withColumn("is_campaign_budget_optimization", col("is_campaign_budget_optimization").cast("boolean"))
        .withColumn("is_flexible_daily_budgets", col("is_flexible_daily_budgets").cast("boolean"))
        .withColumn("is_performance_plus", col("is_performance_plus").cast("boolean"))
        .withColumn("created_time", F.to_timestamp(F.from_unixtime(col("created_time").cast("long"))))
        .withColumn("updated_time", F.to_timestamp(F.from_unixtime(col("updated_time").cast("long"))))
        .withColumn("start_time", F.to_timestamp(F.from_unixtime(col("start_time").cast("long"))))
        .withColumn("end_time", F.to_timestamp(F.from_unixtime(col("end_time").cast("long"))))
    )

def cast_instagram(df):
    return (
        df
        .withColumn("clicks", col("clicks").cast("int"))
        .withColumn("impressions", col("impressions").cast("int"))
        .withColumn("reach", col("reach").cast("int"))
        .withColumn("frequency", col("frequency").cast("float"))
        .withColumn("spend", col("spend").cast("float"))
        .withColumn("unique_clicks", col("unique_clicks").cast("int"))
        .withColumn("full_view_reach", col("full_view_reach").cast("int"))
        .withColumn("cpc", col("cpc").cast("float"))
        .withColumn("cpm", col("cpm").cast("float"))
        .withColumn("cpp", col("cpp").cast("float"))
        .withColumn("created_time", F.to_timestamp("created_time"))
        .withColumn("updated_time", F.to_timestamp("updated_time"))
    )

def cast_facebook(df):
    return (
        df
        .withColumn("clicks", col("clicks").cast("int"))
        .withColumn("impressions", col("impressions").cast("int"))
        .withColumn("reach", col("reach").cast("int"))
        .withColumn("frequency", col("frequency").cast("float"))
        .withColumn("spend", col("spend").cast("float"))
        .withColumn("unique_clicks", col("unique_clicks").cast("int"))
        .withColumn("ctr", col("ctr").cast("float"))
        .withColumn("cpc", col("cpc").cast("float"))
        .withColumn("cpm", col("cpm").cast("float"))
        .withColumn("created_time", F.to_timestamp("created_time"))
        .withColumn("updated_time", F.to_timestamp("updated_time"))
    )

def cast_snapchat(df):
    return (
        df
        .withColumn("created_at", F.to_timestamp("created_at"))
        .withColumn("updated_at", F.to_timestamp("updated_at"))
        .withColumnRenamed("id", "ad_id")
        .withColumnRenamed("name", "ad_name")
    )

def cast_linkedin(df):
    return (
        df
        .withColumn("createdAt", F.to_timestamp(F.from_unixtime(col("createdAt").cast("long") / 1000)))
        .withColumn("lastModifiedAt", F.to_timestamp(F.from_unixtime(col("lastModifiedAt").cast("long") / 1000)))
        .withColumn("isServing", col("isServing").cast("boolean"))
        .withColumn("isTest", col("isTest").cast("boolean"))
        .withColumnRenamed("createdAt", "created_at")
        .withColumnRenamed("createdBy", "created_by")
        .withColumnRenamed("id", "ad_id")
        .withColumnRenamed("intendedStatus", "intended_status")
        .withColumnRenamed("lastModifiedAt", "last_modified_at")
        .withColumnRenamed("lastModifiedBy", "last_modified_by")
        .withColumnRenamed("name", "ad_name")
        .withColumnRenamed("isServing", "is_serving")
        .withColumnRenamed("isTest", "is_test")
        .withColumnRenamed("servingHoldReasons", "serving_hold_reasons")
    )


CASTERS = {
    "tiktok": cast_tiktok,
    "instagram": cast_instagram,
    "facebook": cast_facebook,
    "pinterest": cast_pinterest,
    "snapchat": cast_snapchat,
    "linkedin": cast_linkedin,
}


def run_spark_transform(spark, config: dict, catalog: str, schema: str):
    platform = config["pipeline"]["platform"].strip().lower()

    source_table = f"{catalog}.{schema}.lnd_{platform}_raw"
    target_table = f"{catalog}.{schema}.fct_{platform}_ad_insights"

    wait_for_data(spark, source_table)

    df = spark.table(source_table)

    if platform not in CASTERS:
        raise ValueError(f"Unsupported platform: {platform}")

    transformed = CASTERS[platform](df)

    (
        transformed
        .write
        .format("delta")
        .mode("overwrite")
        .saveAsTable(target_table)
    )

    print(f"Transformation complete: {source_table} -> {target_table}")