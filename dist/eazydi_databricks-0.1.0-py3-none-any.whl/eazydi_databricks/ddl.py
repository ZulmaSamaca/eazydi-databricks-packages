import time
from typing import List
import importlib.resources as pkg_resources
import eazydi_databricks

def get_ddl_path() -> str:
    ref = pkg_resources.files(eazydi_databricks).joinpath("ddl.sql")
    with pkg_resources.as_file(ref) as p:
        return str(p)

def execute_ddl(spark, catalog: str, schema: str) -> List[str]:
    ddl_path = get_ddl_path()
    with open(ddl_path, "r", encoding="utf-8") as f:
        ddl_script = f.read()

    ddl_script = ddl_script.replace("workspace.default", f"{catalog}.{schema}")

    before = {
        row.tableName
        for row in spark.sql(f"SHOW TABLES IN {catalog}.{schema}").collect()
    }

    start_time = time.time()

    for stmt in ddl_script.split(";"):
        if stmt.strip():
            spark.sql(stmt)

    after = {
        row.tableName
        for row in spark.sql(f"SHOW TABLES IN {catalog}.{schema}").collect()
    }

    created_tables = sorted(after - before)
    elapsed = round(time.time() - start_time, 2)

    print(f"DDL execution time: {elapsed}s")
    for table in created_tables:
        print(f"Table created: {table}")

    return created_tables


def apply_grants(spark, catalog: str, schema: str, principal: str, tables: list[str]) -> None:
    if not principal:
        print("No principal provided. Skipping grants.")
        return

    for table in tables:
        table_fqn = f"{catalog}.{schema}.{table}"
        try:
            spark.sql(f"GRANT SELECT ON TABLE {table_fqn} TO `{principal}`")
            spark.sql(f"GRANT MODIFY ON TABLE {table_fqn} TO `{principal}`")
            print(f"Grants applied on: {table_fqn}")
        except Exception:
            spark.sql(f"GRANT SELECT ON TABLE {table_fqn} TO `{principal}`")
            print(f"Only SELECT applied on: {table_fqn}")